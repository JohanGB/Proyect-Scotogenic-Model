# -*- coding: utf-8 -*-
from ROOT import *
import os
import math
import matplotlib.pyplot as plt
import numpy as np
from scipy.stats import lognorm
from sklearn.preprocessing import MinMaxScaler
import matplotlib.colors as colors

# Abrir los archivos .root
testfile1 = TFile('Results_Chains_mcmc.root')

# Obtener los árboles de ambos archivos
tree1 = testfile1.Get("ScanTree")

# Crear listas vacías para el primer archivo (Random Walk)
MH_1, Omega_h2_1 = [], []

# Crear listas vacías para el segundo archivo (Chains_H)
MH_2, Omega_h2_2 = [], []

# Crear listas vacías para las masas de los candidatos
MX01_1, MP01_1, MEtI_1 = [], [], []
MX01_2, MP01_2, MEtI_2 = [], [], []

# Crear listas vacías para los acoples de Yukawa
ge_1, gm_1, gt_1 = [], [], []
ge_2, gm_2, gt_2 = [], [], []

m_nu1_CI_1, m_nu2_CI_1, m_nu3_CI_1 = [], [], []
m_nu1_SPheno_1, m_nu2_SPheno_1, m_nu3_SPheno_1 = [], [], []

m_nu1_CI_2, m_nu2_CI_2, m_nu3_CI_2 = [], [], []
m_nu1_SPheno_2, m_nu2_SPheno_2, m_nu3_SPheno_2 = [], [], []

Yn_11_1, Yn_12_1, Yn_13_1 = [], [], []
Yn_21_1, Yn_22_1, Yn_23_1 = [], [], []
Yn_31_1, Yn_32_1, Yn_33_1 = [], [], []

Yn_11_2, Yn_12_2, Yn_13_2 = [], [], []
Yn_21_2, Yn_22_2, Yn_23_2 = [], [], []
Yn_31_2, Yn_32_2, Yn_33_2 = [], [], []

MEG_1, M3E_1 = [], []
MEG_2, M3E_2 = [], []


# Extraer los datos del primer archivo (Random Walk)
for x in tree1:
    MH_1.append(abs(x.MH))
    Omega_h2_1.append(abs(x.Omega_h2))
    MX01_1.append(abs(x.MX01))
    MP01_1.append(abs(x.MP01))
    MEtI_1.append(abs(x.MEtI))
    m_nu1_CI_1.append(abs(x.m_nu1_CI))
    m_nu2_CI_1.append(abs(x.m_nu2_CI))
    m_nu3_CI_1.append(abs(x.m_nu3_CI))
    m_nu1_SPheno_1.append(abs(x.m_nu1_SPheno))
    m_nu2_SPheno_1.append(abs(x.m_nu2_SPheno))
    m_nu3_SPheno_1.append(abs(x.m_nu3_SPheno))
    Yn_11_1.append(math.sqrt(x.RYn_11**2 + x.IYn11**2))
    Yn_12_1.append(math.sqrt(x.RYn_12**2 + x.IYn12**2))
    Yn_13_1.append(math.sqrt(x.RYn_13**2 + x.IYn13**2))
    Yn_21_1.append(math.sqrt(x.RYn_21**2 + x.IYn21**2))
    Yn_22_1.append(math.sqrt(x.RYn_22**2 + x.IYn22**2))
    Yn_23_1.append(math.sqrt(x.RYn_23**2 + x.IYn23**2))
    Yn_31_1.append(math.sqrt(x.RYn_31**2 + x.IYn31**2))
    Yn_32_1.append(math.sqrt(x.RYn_32**2 + x.IYn32**2))
    Yn_33_1.append(math.sqrt(x.RYn_33**2 + x.IYn33**2))
    #MEG_1.append(abs(x.BrMEG))
    #M3E_1.append(abs(x.BrM3E))
    

# Contar el número total de puntos
total_puntos1 = len(Omega_h2_1)
rango_min = 0.1198 - 0.0042
rango_max = 0.1198 + 0.0042
puntos_en_rango1 = [punto for punto in Omega_h2_1 if rango_min <= punto <= rango_max]
cantidad_en_rango1 = len(puntos_en_rango1)

print(f"Total points for MCMC relic density: {total_puntos1}")
print(f"Solution points for MCMC: Points into the range ({rango_min}, {rango_max}): {cantidad_en_rango1}")