# -*- coding: utf-8 -*-
from ROOT import *
import os
import math
import matplotlib.pyplot as plt
import numpy as np
from scipy.stats import lognorm
from sklearn.preprocessing import MinMaxScaler
import matplotlib.colors as colors

# Abrir los archivos .root
testfile1 = TFile('Results_Chains_DD.root')

# Obtener los árboles de ambos archivos
tree1 = testfile1.Get("ScanTree")

# Crear listas vacías para el primer archivo (Random Walk)
MH_1, Omega_h2_1 = [], []

# Crear listas vacías para el segundo archivo (Chains_H)
MH_2, Omega_h2_2 = [], []

# Crear listas vacías para las masas de los candidatos
MX01_1, MP01_1, MEtI_1 = [], [], []
MX01_2, MP01_2, MEtI_2 = [], [], []

# Crear listas vacías para los acoples de Yukawa
ge_1, gm_1, gt_1 = [], [], []
ge_2, gm_2, gt_2 = [], [], []

m_nu1_CI_1, m_nu2_CI_1, m_nu3_CI_1 = [], [], []
m_nu1_SPheno_1, m_nu2_SPheno_1, m_nu3_SPheno_1 = [], [], []

m_nu1_CI_2, m_nu2_CI_2, m_nu3_CI_2 = [], [], []
m_nu1_SPheno_2, m_nu2_SPheno_2, m_nu3_SPheno_2 = [], [], []

Yn_11_1, Yn_12_1, Yn_13_1 = [], [], []
Yn_21_1, Yn_22_1, Yn_23_1 = [], [], []
Yn_31_1, Yn_32_1, Yn_33_1 = [], [], []

Yn_11_2, Yn_12_2, Yn_13_2 = [], [], []
Yn_21_2, Yn_22_2, Yn_23_2 = [], [], []
Yn_31_2, Yn_32_2, Yn_33_2 = [], [], []

MEG_1, M3E_1 = [], []
MEG_2, M3E_2 = [], []

l1_1, l4Sig_1, l4Eta_1, lHSig_1, l32HEta_1, l33HEta_1 = [], [], [], [], [], []
lEtaSig_1, cTri_1, Sig_1, Eta_1, l31HEta_1 = [], [], [], [], []
l1_2, l4Sig_2, l4Eta_2, lHSig_2, l32HEta_2, l33HEta_2 = [], [], [], [], [], []
lEtaSig_2, cTri_2, Sig_2, Eta_2, l31HEta_2 = [], [], [], [], []

MSig2_1, MEta2_1, mH2_1 = [], [], []
MSig2_2, MEta2_2, mH2_2 = [], [], []

mN11_1, mN22_1, mN33_1  = [], [], []
mN11_2, mN22_2, mN33_2  = [], [], []

mnu1_1, dm212_1, dm312_1 =  [], [], []
mnu1_2, dm212_2, dm312_2 =  [], [], []

theta_12_1, theta_13_1, theta_23_1 = [], [], []
theta_22_2, theta_23_2, theta_23_2 = [], [], []

delta_d_1, delta_m1_1, delta_m2_1, delta_m3_1 = [], [], [], []
delta_d_2, delta_m1_2, delta_m2_2, delta_m3_2 = [], [], [], []

Theta1_1, Theta2_1, Theta3_1, alpha_1, = [], [], [], []
Theta1_2, Theta2_2, Theta3_2, alpha_2, = [], [], [], []

MX02_1, MX03_1, MP02_1 = [], [], []
MX02_2, MX03_2, MP02_2 = [], [], []

m_nu1_Inputs_1, Dnu_21_Inputs_1, Dnu_31_Inputs_1 = [], [], []
m_nu1_Inputs_2, Dnu_21_Inputs_2, Dnu_31_Inputs_2 = [], [], []

mN11_1, mN22_1, mN33_1 = [], [], []
mN11_2, mN22_2, mN33_2 = [], [], []

Zscalar11_1, Zscalar12_1, Zscalar21_1, Zscalar22_1 = [], [], [], []
Zscalar11_2, Zscalar12_2, Zscalar21_2, Zscalar22_2 = [], [], [], []

RZX11_1, RZX12_1, RZX13_1 = [], [], []
RZX21_1, RZX22_1, RZX23_1 = [], [], []
RZX31_1, RZX32_1, RZX33_1 = [], [], [] 
RZX11_2, RZX12_2, RZX13_2 = [], [], []
RZX21_2, RZX22_2, RZX23_2 = [], [], []
RZX31_2, RZX32_2, RZX33_2 = [], [], [] 

g_2e_1, g_2m_1, g_2t_1, Spar_1 = [], [], [], []
Tpar_1, Upar_1, BrHEM_1, BrHET_1, BrHTM_1 = [], [], [], [], []
GammaH1_1, GammaH2_1, Likelihood_1 = [], [], [] 
g_2e_2, g_2m_2, g_2t_2, Spar_2 = [], [], [], []
Tpar_2, Upar_2, BrHEM_2, BrHET_2, BrHTM_2 = [], [], [], [], []
GammaH1_2, GammaH2_2, Likelihood_2 = [], [], [] 

BrMEG_1, BrM3E_1, BrTEG_1, BrTMG_1, BrT3E_1, BrT3M_1 = [], [], [], [], [], []
BrTMp2E_1, BrTMm2E_1, BrTEp2M_1, BrTEm2M_1, BrTEpi_1, BrTEeta_1 = [], [], [], [], [], []
BrTEetaP_1, BrTMpi_1, BrTMeta_1, BrTMetaP_1 =[], [], [], []
CrTi_1, CrPb_1, CrAu_1, BrZEM_1, BrZET_1, BrZMT_1 = [], [], [], [], [], []
BrMEG_2, BrM3E_2, BrTEG_2, BrTMG_2, BrT3E_2, BrT3M_2 = [], [], [], [], [], []
BrTMp2E_2, BrTMm2E_2,BrTEp2M_2, BrTEm2M_2, BrTEpi_2, BrTEeta_2 = [], [], [], [], [], []
BrTEetaP_2, BrTMpi_2, BrTMeta_2, BrTMetaP_2 =[], [], [], []
CrTi_2, CrPb_2, CrAu_2, BrZEM_2, BrZET_2, BrZMT_2 = [], [], [], [], [], []

# Extraer los datos del primer archivo (Random Walk)
for x in tree1:
    MH_1.append(abs(x.MH))
    Omega_h2_1.append(abs(x.Omega_h2))
    MX01_1.append(abs(x.MX01))
    MP01_1.append(abs(x.MP01))
    MEtI_1.append(abs(x.MEtI))
    m_nu1_CI_1.append(abs(x.m_nu1_CI))
    m_nu2_CI_1.append(abs(x.m_nu2_CI))
    m_nu3_CI_1.append(abs(x.m_nu3_CI))
    m_nu1_SPheno_1.append(abs(x.m_nu1_SPheno))
    m_nu2_SPheno_1.append(abs(x.m_nu2_SPheno))
    m_nu3_SPheno_1.append(abs(x.m_nu3_SPheno))
    Yn_11_1.append(math.sqrt(x.RYn_11**2 + x.IYn11**2))
    Yn_12_1.append(math.sqrt(x.RYn_12**2 + x.IYn12**2))
    Yn_13_1.append(math.sqrt(x.RYn_13**2 + x.IYn13**2))
    Yn_21_1.append(math.sqrt(x.RYn_21**2 + x.IYn21**2))
    Yn_22_1.append(math.sqrt(x.RYn_22**2 + x.IYn22**2))
    Yn_23_1.append(math.sqrt(x.RYn_23**2 + x.IYn23**2))
    Yn_31_1.append(math.sqrt(x.RYn_31**2 + x.IYn31**2))
    Yn_32_1.append(math.sqrt(x.RYn_32**2 + x.IYn32**2))
    Yn_33_1.append(math.sqrt(x.RYn_33**2 + x.IYn33**2))
    l1_1.append(abs(x.l1))
    l4Sig_1.append(abs(x.l4Sig))
    l4Eta_1.append(abs(x.l4Eta))
    lHSig_1.append(abs(x.lHSig))
    l32HEta_1.append(abs(x.l32HEta))
    l33HEta_1.append(abs(x.l33HEta))
    lEtaSig_1.append(abs(x.lEtaSig))
    cTri_1.append(abs(x.cTri))
    Sig_1.append(abs(x.Sig))
    Eta_1.append(abs(x.Eta))
    l31HEta_1.append(abs(x.l31HEta))
    MSig2_1.append(abs(x.MSig2))
    MEta2_1.append(abs(x.MEta2))
    mH2_1.append(abs(x.mH2))
    mN11_1.append(abs(x.mN11))
    mN22_1.append(abs(x.mN22))
    mN33_1.append(abs(x.mN33))
    mnu1_1.append(abs(x.mnu1))
    dm212_1.append(abs(x.dm212))
    dm312_1.append(abs(x.dm312))
    theta_12_1.append(abs(x.theta_12))
    theta_13_1.append(abs(x.theta_13))
    theta_23_1.append(abs(x.theta_23))
    delta_d_1.append(abs(x.delta_d))
    delta_m1_1.append(abs(x.delta_m1))
    delta_m2_1.append(abs(x.delta_m2))
    delta_m3_1.append(abs(x.delta_m3))
    Theta1_1.append(abs(x.Theta1))
    Theta2_1.append(abs(x.Theta2))
    Theta3_1.append(abs(x.Theta3))
    alpha_1.append(abs(x.alpha))
    MP02_1.append(abs(x.MP02))
    MX02_1.append(abs(x.MX02))
    MX03_1.append(abs(x.MX03))
    m_nu1_Inputs_1.append(abs(x.m_nu1_Inputs))
    Dnu_21_Inputs_1.append(abs(x.Dnu_21_Inputs))
    Dnu_31_Inputs_1.append(abs(x.Dnu_31_Inputs))
    mN11_1.append(abs(x.mN11))
    mN22_1.append(abs(x.mN22))
    mN33_1.append(abs(x.mN33))
    Zscalar11_1.append(abs(x.Zscalar11))
    Zscalar12_1.append(abs(x.Zscalar12))
    Zscalar21_1.append(abs(x.Zscalar21))
    Zscalar22_1.append(abs(x.Zscalar22))
    RZX11_1.append(abs(x.RZX11))
    RZX12_1.append(abs(x.RZX12))
    RZX13_1.append(abs(x.RZX13))
    RZX21_1.append(abs(x.RZX21))
    RZX22_1.append(abs(x.RZX22))
    RZX23_1.append(abs(x.RZX23))
    RZX31_1.append(abs(x.RZX31))
    RZX32_1.append(abs(x.RZX32))
    RZX33_1.append(abs(x.RZX33))
    g_2e_1.append(abs(x.g_2e))
    g_2m_1.append(abs(x.g_2m))
    g_2t_1.append(abs(x.g_2t))
    Spar_1.append(abs(x.Spar))
    Tpar_1.append(abs(x.Tpar))
    Upar_1.append(abs(x.Upar))
    BrHEM_1.append(abs(x.BrHEM))
    BrHET_1.append(abs(x.BrHET))
    BrHTM_1.append(abs(x.BrHTM))
    GammaH1_1.append(abs(x.GammaH1))
    GammaH2_1.append(abs(x.GammaH2))
    Likelihood_1.append(abs(x.Likelihood))
    MEG_2.append(abs(x.BrMEG))
    M3E_2.append(abs(x.BrM3E))
    BrTEG_2.append(abs(x.BrTEG))
    BrTMG_2.append(abs(x.BrTMG))
    BrT3E_2.append(abs(x.BrT3E))
    BrT3M_2.append(abs(x.BrT3M))
    BrTMp2E_2.append(abs(x.BrTMp2E))
    BrTMm2E_2.append(abs(x.BrTMm2E))
    BrTEp2M_2.append(abs(x.BrTEp2M))
    BrTEm2M_2.append(abs(x.BrTEm2M))
    BrTEpi_2.append(abs(x.BrTEpi))
    BrTEeta_2.append(abs(x.BrTEeta))
    BrTEetaP_2.append(abs(x.BrTEetaP))
    BrTMpi_2.append(abs(x.BrTMpi))
    BrTMeta_2.append(abs(x.BrTMeta))
    BrTMetaP_2.append(abs(x.BrTMetaP))
    CrTi_2.append(abs(x.CrTi))
    CrPb_2.append(abs(x.CrPb))
    CrAu_2.append(abs(x.CrAu))
    BrZEM_2.append(abs(x.BrZEM))
    BrZET_2.append(abs(x.BrZET))
    BrZMT_2.append(abs(x.BrZMT))    

    
#print("Test MEG : ",MEG_2[0],MEG_2[15])

# Contar el número total de puntos
total_puntos1 = len(Omega_h2_1)
rango_min = 0.1198 - 0.0042
rango_max = 0.1198 + 0.0042
puntos_en_rango1 = [punto for punto in Omega_h2_1 if rango_min <= punto <= rango_max]
cantidad_en_rango1 = len(puntos_en_rango1)

print(f"Total points for MCMC DD relic density: {total_puntos1} with {cantidad_en_rango1} solutions" )


"""
# Definir el número de bines y el rango para las gráficas
bins = 100

def filtrar_datos(masas, omega_h2):
    masas_filtradas = []
    omega_h2_filtered = []
    for masa, omega in zip(masas, omega_h2):
        if omega > 1e23:
            masas_filtradas.append(masa)
            omega_h2_filtered.append(omega)
    return masas_filtradas, omega_h2_filtered

MX01_1_filtered, Omega_h2_1_filtered = filtrar_datos(MX01_1, Omega_h2_1)
MP01_1_filtered, Omega_h2_1_filtered = filtrar_datos(MP01_1, Omega_h2_1)
MEtI_1_filtered, Omega_h2_1_filtered = filtrar_datos(MEtI_1, Omega_h2_1)

MX01_2_filtered, Omega_h2_2_filtered = filtrar_datos(MX01_2, Omega_h2_2)
MP01_2_filtered, Omega_h2_2_filtered = filtrar_datos(MP01_2, Omega_h2_2)
MEtI_2_filtered, Omega_h2_2_filtered = filtrar_datos(MEtI_2, Omega_h2_2)

# Comparación de la masa del Higgs (MH)
plt.hist(MH_1, bins=bins, edgecolor='black', histtype='step', label='Random Walk',density=True)
plt.hist(MH_2, bins=bins, edgecolor='blue', histtype='step', label='MCMC with LFV', density=True)

plt.axvline(x=125, color='red', linestyle='--', linewidth=1, label='Expected MH = 125 GeV')
plt.yscale('log')
plt.title('Comparison of Higgs Mass (MH)')
plt.xlabel('MH [GeV]')
plt.ylabel('')
#plt.xlim(0, 800)
plt.legend()
plt.savefig('comparison_MH_normalized.png')
plt.clf()

# Comparación de la densidad reliquia (Omega_h2)
#Omega_h2_1_filtered = [oh for oh in Omega_h2_1 if 0.0 < oh < 0.2]
#Omega_h2_2_filtered = [oh for oh in Omega_h2_2 if 0.0 < oh < 0.2]

plt.hist(Omega_h2_1_filtered, bins=100, edgecolor='black', histtype='step', label='Random Walk', density=True)
plt.hist(Omega_h2_2_filtered, bins=100, edgecolor='blue', histtype='step', label='MCMC with LFV', density=True)

plt.axvspan(0.1199 - 0.0012, 0.1199 + 0.0012, color='red', alpha=0.3, label=r'Expected $\Omega_{h^2} = 0.1199 \pm 0.0012$')
plt.yscale('log')
plt.title('Comparison of Relic Density ($\Omega_{h^2}$)')
plt.xlabel(r'$\Omega_{h^2}$')
plt.ylabel('')
plt.xlim(0,0.15)
plt.legend()
plt.savefig('comparison_Omega_h2_normalized.png')
plt.clf()

# Suponiendo que MX01_2, MP01_2 y MEtI_2 son tus listas originales
MX01_1_filtered_cand = []
MP01_1_filtered_cand = []
MEtI_1_filtered_cand = []

MX01_2_filtered_cand = []
MP01_2_filtered_cand = []
MEtI_2_filtered_cand = []

# Filtrar los valores
for mx, mp, mi in zip(MX01_2, MP01_2, MEtI_2):
    min_val = min(mx, mp, mi)
    if min_val == mx:
        MX01_2_filtered_cand.append(mx)
    elif min_val == mp:
        MP01_2_filtered_cand.append(mp)
    elif min_val == mi:
        MEtI_2_filtered_cand.append(mi)

# Crear los histogramas
plt.hist(MX01_2_filtered_cand, bins=50, edgecolor='red', histtype='step', label=r'$M_{\chi_{1}}$', density=True)
plt.hist(MP01_2_filtered_cand, bins=50, edgecolor='green', histtype='step', label=r'$M_{\phi^{0}_{1}}$', density=True)
plt.hist(MEtI_2_filtered_cand, bins=50, edgecolor='blue', histtype='step', label=r'$M_{\eta_{I}}$')#,density=True )
plt.title('Comparison of Masses When for DM candidate MCMC with LFV')
plt.xlabel('Mass Dark Matter [GeV]')
plt.ylabel('')
plt.legend()
plt.savefig('comparison_Candidates_MCMC.png')
plt.clf()


# Filtrar los valores
for my, mph, me in zip(MX01_1, MP01_1, MEtI_1):
    min_value = min(my, mph, me)
    if min_value == my:
        MX01_1_filtered_cand.append(my)
    elif min_value == mph:
        MP01_1_filtered_cand.append(mph)
    elif min_value == me:
        MEtI_1_filtered_cand.append(me)
# Crear los histogramas
plt.hist(MX01_1_filtered_cand, bins=50, edgecolor='red', histtype='step', label=r'$M_{\chi_{1}}$', density=True)
plt.hist(MP01_1_filtered_cand, bins=50, edgecolor='green', histtype='step', label=r'$M_{\phi^{0}_{1}}$', density=True)
plt.hist(MEtI_1_filtered_cand, bins=50, edgecolor='blue', histtype='step', label=r'$M_{\eta_{I}}$',density=True)

# Títulos y etiquetas
plt.title('Comparison of Masses When for DM candidate Random Walk')
plt.xlabel('Mass Dark Matter [GeV]')
plt.yscale('log')
plt.ylabel('')
plt.legend()
plt.savefig('comparison_Candidates_RW.png')
plt.clf()
"""

"""
# Comparación de acoples de Yukawa (ge, gm, gt) RW con MCMC

def hist_ycouplings(Yn1, Yn2, lepton, gen, color, nombre):
    plt.hist(Yn1, bins=50, edgecolor='black', histtype='step', label=f'$|g^{lepton}_{gen}|$ Random Walk', density=True)
    plt.hist(Yn2, bins=50, edgecolor=color, histtype='step', label=f'$|g^{lepton}_{gen}|$ MCMC with LFV', density=True)
    plt.title(f'Comparison of Yukawa Coupling $|g^{lepton}_{gen}|$')
    plt.yscale('log')
    #plt.xscale('log')
    plt.xlabel(f'$|g^{lepton}_{gen}|$')
    plt.ylabel('')
    plt.legend()
    plt.savefig(f'comparison_g_{nombre}_{gen}.png')
    plt.clf()

# Llamadas a la función
hist_ycouplings(Yn_11_1, Yn_11_2, 'e', '1','red','e')
hist_ycouplings(Yn_21_1, Yn_21_2, 'e', '2','red','e')
hist_ycouplings(Yn_31_1, Yn_31_2, 'e', '3','red','e')
hist_ycouplings(Yn_12_1, Yn_12_2, r'\mu', '1','blue','mu')
hist_ycouplings(Yn_22_1, Yn_22_2, r'\mu', '2','blue','mu')
hist_ycouplings(Yn_32_1, Yn_32_2, r'\mu', '3','blue','mu')
hist_ycouplings(Yn_13_1, Yn_13_2, r'\tau', '1','green','tau')
hist_ycouplings(Yn_23_1, Yn_23_2, r'\tau', '2','green','tau')
hist_ycouplings(Yn_33_1, Yn_33_2, r'\tau', '3','green','tau')

# Comparación de acoples de Yukawa (ge, gm, gt) entre gens.

def hist_ycouplings(Yn1, Yn2, Yn3, lepton,nombre):
    plt.hist(Yn1, bins=50, edgecolor='red', histtype='step', label=f'$|g^{lepton}_1|$', density=True)
    plt.hist(Yn2, bins=50, edgecolor='blue', histtype='step', label=f'$|g^{lepton}_2|$', density=True)
    plt.hist(Yn3, bins=50, edgecolor='green', histtype='step', label=f'$|g^{lepton}_3|$', density=True)
    plt.title(f'Comparison of Yukawa Coupling $|g^{lepton}_(n)|$ for MCMC with LFV')
    plt.yscale('log')
    #plt.xscale('log')
    plt.xlabel(f'$|g^{lepton}_(1,2,3)|$')
    plt.ylabel('')
    plt.legend()
    plt.savefig(f'comparison_g_{nombre}_gens.png')
    plt.clf()

hist_ycouplings(Yn_11_2, Yn_21_2, Yn_31_2, 'e', 'e')
hist_ycouplings(Yn_12_2, Yn_22_2, Yn_32_2,r'\mu','mu')
hist_ycouplings(Yn_13_2, Yn_23_2, Yn_33_2,r'\tau','tau')


def scatter_couplings(X, Y, Z, gen):
    X = np.array(X)
    Y = np.array(Y)
    Z = np.array(Z)
    
    scatter = plt.scatter(X, Y, c=Z, cmap='viridis', s=10, norm=colors.LogNorm())
    cbar = plt.colorbar(scatter)
    cbar.set_label(f'$|Y^\\tau_{gen}|$')
    plt.title(f'Yukawa Coupling Comparison for $|Y_{gen}|$')
    plt.xlabel(f'$|Y^e_{gen}|$')
    plt.ylabel(f'$|Y^\\mu_{gen}|$')
    plt.yscale('log')
    plt.xscale('log')
    plt.savefig(f'comparison_yukawa_coupling_{gen}.png')
    plt.clf()

scatter_couplings(Yn_11_2, Yn_12_2, Yn_13_2, '1')
scatter_couplings(Yn_21_2, Yn_22_2, Yn_23_2, '2')
scatter_couplings(Yn_31_2, Yn_32_2, Yn_33_2, '3')

# Función para graficar el valor medio de los acoples
mean_couplings_e, mean_couplings_mu, mean_couplings_tau = [], [], []

for y in range(len(Yn_11_2)):
    mean_couplings_e.append((Yn_11_2[y] * Yn_12_2[y] * Yn_13_2[y])**(1/3))
    mean_couplings_mu.append((Yn_21_2[y] * Yn_22_2[y] * Yn_23_2[y])**(1/3))
    mean_couplings_tau.append((Yn_31_2[y] * Yn_32_2[y] * Yn_33_2[y])**(1/3))

def plot_mean_couplings(mean_couplings, lepton,nombre):
    plt.figure()
    plt.hist(mean_couplings, bins=50, edgecolor='blue', histtype='step', density=True)
    plt.title(f'Mean Yukawa Coupling for {lepton}')
    plt.xlabel(f'Mean $|g^{{{lepton}}}|$')
    plt.ylabel('')
    plt.yscale('log')
    plt.savefig(f'mean_yukawa_coupling_{nombre}.png')
    plt.clf()

plot_mean_couplings(mean_couplings_e, 'e','e')
plot_mean_couplings(mean_couplings_mu, r'\mu','mu')
plot_mean_couplings(mean_couplings_tau, r'\tau','tau')

# Calcular el valor medio geométrico total de los acoples
mean_total_couplings_2 = []

for y in range(len(Yn_11_2)):
    mean_total_couplings_2.append((Yn_11_2[y] * Yn_12_2[y] * Yn_13_2[y] *
                     Yn_21_2[y] * Yn_22_2[y] * Yn_23_2[y] *
                     Yn_31_2[y] * Yn_32_2[y] * Yn_33_2[y])**(1/9))

plt.hist(mean_total_couplings_2, bins=15, edgecolor='red', histtype='step', density=True)
plt.title('Mean Yukawa Coupling')
plt.xlabel(r'$\bar{G}$')
plt.ylabel('')
#plt.yscale('log')
#plt.xscale('log')
plt.savefig('mean_yukawa_coupling.png')
plt.clf()



# Comparacion BR(M->E+G) con BR(M->3E)

limite_meg = 4.2e-13 + 0.42e-13
limite_m3e = 1.0e-12 + 0.10e-12
filtered_meg_2 = [meg for meg in MEG_2 if meg <= limite_meg]
filtered_m3e_2 = [m3e for m3e in M3E_2 if m3e <= limite_m3e]

plt.scatter(filtered_meg_2, filtered_m3e_2, c='blue', s=5, label='MCMC with LFV')
plt.axvline(x=4.2e-13, color='black', linestyle='--', label=r'Experimental value $\mu \rightarrow e + \gamma$')
plt.axhline(y=1.0e-12, color='red', linestyle='--', label=r'Experimental value $\mu \rightarrow 3e$')
plt.xlabel(r'$\mu \rightarrow e + \gamma$')
plt.ylabel(r'$\mu \rightarrow 3e$')
plt.title('Gráfica de BrMEG vs. BrM3E')
plt.yscale('log')
plt.xscale('log')
plt.legend()
plt.savefig('grafica_brmeg_brm3e.png')
plt.clf()



# Comparación de las masas de los tres candidatos (con el mismo binning)
plt.hist(MX01_2_filtered, bins=20 ,edgecolor='red', histtype='step', label=r'$M_{\chi_{1}}$', density=True)
plt.hist(MP01_2_filtered, bins=20 ,edgecolor='green', histtype='step', label=r'$M_{\phi^{0}_{1}}$', density=True)
plt.hist(MEtI_2_filtered, bins=100 ,edgecolor='blue', histtype='step', label=r'$M_{\eta_{I}}$', density=True)

# Títulos y etiquetas
plt.title('Comparison of Masses of Three Candidates (MX01, MP01, MEtI)')
plt.xlim(0, 1000)
plt.xlabel('Mass [GeV]')
plt.ylabel('Normalized Frequency')
plt.legend()

# Guardar y limpiar el gráfico
plt.savefig('comparison_Candidates_same_binning.png')
plt.clf()


# Gráficas de ohmh2 vs masa de los candidatos
# MX01 vs Omega_h2
plt.scatter(MX01_2_filtered, Omega_h2_2_filtered, c='red', label=r'$M_{\chi_{1}}$')
plt.axhspan(0.1199 - 0.0012, 0.1199 + 0.0012, color='red', alpha=0.3, label=r'Expected $\Omega_{h^2} = 0.1199 \pm 0.0012$')
plt.xlabel(r'$M_{\chi_{1}}$ [GeV]')
plt.ylabel(r'$\Omega_{h^2}$')
plt.title(r'$M_{\chi_{1}}$ vs $\Omega_{h^2}$')
#plt.yscale('log')
plt.legend()
plt.savefig('MX01_vs_Ohmh2.png')
plt.clf()

# MP01 vs Omega_h2
plt.scatter(MP01_2_filtered, Omega_h2_2_filtered, c='green', label=r'$M_{\phi^{0}_{1}}$')
plt.axhspan(0.1199 - 0.0012, 0.1199 + 0.0012, color='red', alpha=0.3, label=r'Expected $\Omega_{h^2} = 0.1199 \pm 0.0012$')
plt.xlabel(r'$M_{\phi^{0}_{1}}$ [GeV]')
plt.ylabel(r'$\Omega_{h^2}$')
plt.title(r'$M_{\phi^{0}_{1}}$ vs $\Omega_{h^2}$')
#plt.yscale('log')
plt.legend()
plt.savefig('MP01_vs_Ohmh2.png')
plt.clf()

# MEtI vs Omega_h2
plt.scatter(MEtI_2_filtered, Omega_h2_2_filtered, c='blue', label=r'$M_{\eta_{I}}$')
plt.axhspan(0.1199 - 0.0012, 0.1199 + 0.0012, color='red', alpha=0.3, label=r'Expected $\Omega_{h^2} = 0.1199 \pm 0.0012$')
plt.xlabel(r'$M_{\eta_{I}}$ [GeV]')
plt.ylabel(r'$\Omega_{h^2}$')
plt.title(r'$M_{\eta_{I}}$ vs $\Omega_{h^2}$')
#plt.yscale('log')
plt.legend()
plt.savefig('MEtI_vs_Ohmh2.png')
plt.clf()
"""
"""
# Comparación de masas vs Omega_h2
plt.scatter(MX01_1_filtered, Omega_h2_1_filtered, c='red', s=5, label=r'$M_{\chi_{1}}$')
plt.scatter(MP01_1_filtered, Omega_h2_1_filtered, c='green', s=5,label=r'$M_{\phi^{0}_{1}}$')
plt.scatter(MEtI_1_filtered, Omega_h2_1_filtered, c='blue', s=5,label=r'$M_{\eta_{I}}$')
plt.axhspan(0.1199 - 0.0012, 0.1199 + 0.0012, color='red', alpha=0.3, label=r'Expected $\Omega_{h^2} = 0.1199 \pm 0.0012$')
plt.yscale('log')
plt.xlim(0,1000)
plt.xlabel(r'Mass DM [GeV]')
plt.ylabel(r'$\Omega_{h^2}$')
plt.title(r'Comparison of Masses vs $\Omega_{h^2} for RW$')
plt.legend()
plt.savefig('comparison_masses_vs_Ohmh2_RW.png')
plt.clf()
"""

"""
# Calcular la diferencia de masas al cuadrado para oscilaciones de neutrinos
def calcular_oscilacion(m_nu1, m_nu2, m_nu3):
    delta_mnu21 = [abs(m2**2 - m1**2) for m1, m2 in zip(m_nu1, m_nu2)]
    delta_mnu31 = [abs(m3**2 - m1**2) for m1, m3 in zip(m_nu1, m_nu3)]
    return delta_mnu21, delta_mnu31

delta_mnu21_CI_1, delta_mnu31_CI_1 = calcular_oscilacion(m_nu1_CI_1, m_nu2_CI_1, m_nu3_CI_1)
delta_mnu21_CI_2, delta_mnu31_CI_2 = calcular_oscilacion(m_nu1_CI_2, m_nu2_CI_2, m_nu3_CI_2)

# Valor experimental para comparación (GeV^2)
#valor_experimental_delta_mnu21 = 7.4e-23  #

# Crear y guardar la gráfica de oscilación
def crear_grafica_oscilacion_mnu21_vs_mnu31(x1, y1, xlabel, ylabel, title, filename):
    plt.scatter(x1, y1, c='blue', s=5, label='MCMC')
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.title(title)
    plt.legend()
    plt.savefig(filename)
    plt.clf()

# Crear gráfica
crear_grafica_oscilacion_mnu21_vs_mnu31(
    delta_mnu21_CI_2, delta_mnu31_CI_2,
    r'$\delta m_{\nu 21}^2$', r'$\delta m_{\nu 31}^2$',
    r'Comparison $\delta m_{\nu 21}^2$ vs $\delta m_{\nu 31}^2$',
    'oscilacion_mnu21_vs_mnu31_MCMC.png'
)

#plt.axvspan(2.534e-21 - 0.023e-21, 2.534e-21 + 0.025e-21, color='red', alpha=0.3, label=r'Expected $\Delta m_{\nu 31}^2$')

# Filtrar valores mayores a 1 y asegurar que las listas tengan el mismo tamaño
def filtrar_datos_mnu(m_nu_CI, m_nu_SPheno):
    m_nu_CI_filtrados = []
    m_nu_SPheno_filtrados = []
    for ci, spheno in zip(m_nu_CI, m_nu_SPheno):
        if ci <= 1e-6 and spheno <= 1e-6:
            m_nu_CI_filtrados.append(ci)
            m_nu_SPheno_filtrados.append(spheno)
    min_len = min(len(m_nu_CI_filtrados), len(m_nu_SPheno_filtrados))
    return m_nu_CI_filtrados[:min_len], m_nu_SPheno_filtrados[:min_len]

# Filtrar los datos
m_nu1_CI_1, m_nu1_SPheno_1 = filtrar_datos_mnu(m_nu1_CI_1, m_nu1_SPheno_1)
m_nu2_CI_1, m_nu2_SPheno_1 = filtrar_datos_mnu(m_nu2_CI_1, m_nu2_SPheno_1)
m_nu3_CI_1, m_nu3_SPheno_1 = filtrar_datos_mnu(m_nu3_CI_1, m_nu3_SPheno_1)
m_nu1_CI_2, m_nu1_SPheno_2 = filtrar_datos_mnu(m_nu1_CI_2, m_nu1_SPheno_2)
m_nu2_CI_2, m_nu2_SPheno_2 = filtrar_datos_mnu(m_nu2_CI_2, m_nu2_SPheno_2)
m_nu3_CI_2, m_nu3_SPheno_2 = filtrar_datos_mnu(m_nu3_CI_2, m_nu3_SPheno_2)

# Función para crear las gráficas y guardarlas
def crear_grafica(x1, y1, x2, y2, xlabel, ylabel, title, filename):
    plt.scatter(x1, y1, c='blue',s=5, label='Random Walk')
    plt.scatter(x2, y2, c='green',s=5, label='MCMC with LFV')
    #plt.plot(rango, rango, color='red', alpha=0.3, label='Experimental range')
    #plt.fill_between(rango, rango * 0.9, rango * 1.1, color='red', alpha=0.1)
    #plt.xlim(0,1e-5)
    #plt.ylim()
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.title(title)
    plt.legend()
    plt.savefig(filename)
    plt.clf()

# Crear y guardar gráficas
#crear_grafica(m_nu1_SPheno_1, m_nu1_CI_1, m_nu1_SPheno_2, m_nu1_CI_2, r'$m_{\nu1_{SPheno}}$', r'$m_{\nu1_{CI}}$', r'$m_{\nu1_{CI}}$ vs $m_{\nu1_{SPheno}}$', 'm_nu1_CI_vs_m_nu1_SPheno.png')
#crear_grafica(m_nu2_SPheno_1, m_nu2_CI_1, m_nu2_SPheno_2, m_nu2_CI_2, r'$m_{\nu2_{SPheno}}$', r'$m_{\nu2_{CI}}$', r'$m_{\nu2_{CI}}$ vs $m_{\nu2_{SPheno}}$', 'm_nu2_CI_vs_m_nu2_SPheno.png')
#crear_grafica(m_nu3_SPheno_1, m_nu3_CI_1, m_nu3_SPheno_2, m_nu3_CI_2, r'$m_{\nu3_{SPheno}}$', r'$m_{\nu3_{CI}}$', r'$m_{\nu3_{CI}}$ vs $m_{\nu3_{SPheno}}$', 'm_nu3_CI_vs_m_nu3_SPheno.png')

#------------------------------------------------------------------------
# Calcular la oscilación de los neutrinos
def calcular_oscilacion(m_nu1, m_nu2):
    return [abs(m2**2 - m1**2) for m1, m2 in zip(m_nu1, m_nu2)]

# Calcular la oscilación para los datos filtrados
oscilacion_CI_1 = calcular_oscilacion(m_nu1_CI_1, m_nu2_CI_1)
oscilacion_SPheno_1 = calcular_oscilacion(m_nu1_SPheno_1, m_nu2_SPheno_1)
oscilacion_CI_2 = calcular_oscilacion(m_nu1_CI_2, m_nu2_CI_2)
oscilacion_SPheno_2 = calcular_oscilacion(m_nu1_SPheno_2, m_nu2_SPheno_2)

# Valor experimental en (GeV)^2
valor_experimental = 7.4e-23

# Comparación de masas vs Omega_h2
plt.scatter(MX01_1_filtered, Omega_h2_1_filtered, c='red', s=5, label=r'$M_{\chi_{1}}$')
plt.scatter(MP01_1_filtered, Omega_h2_1_filtered, c='green', s=5,label=r'$M_{\phi^{0}_{1}}$')
plt.scatter(MEtI_1_filtered, Omega_h2_1_filtered, c='blue', s=5,label=r'$M_{\eta_{I}}$')
plt.axhspan(0.1199 - 0.0012, 0.1199 + 0.0012, color='red', alpha=0.3, label=r'Expected $\Omega_{h^2} = 0.1199 \pm 0.0012$')
plt.xlabel(r'Mass [GeV]')
plt.ylabel(r'$\Omega_{h^2}$')
plt.title(r'Comparison of Masses vs $\Omega_{h^2} for RW$')
plt.legend()
plt.savefig('comparison_masses_vs_Ohmh2_RW.png')
plt.clf()

# Función para crear la gráfica y guardarla
def crear_grafica_oscilacion(x1, y1, x2, y2, xlabel, ylabel, title, valor_experimental, filename):
    #plt.scatter(x1, y1, c='blue', label='Random Walk')
    plt.scatter(x2, y2, c='green',s=5, label='MCMC with LFV')
    plt.axline((0, 0), slope=1, color='red', linestyle='--', label=f'Experimental value = {valor_experimental:.2e}')
    #plt.axhline(valor_experimental, color='purple', linestyle='--', label=f'Experimental value = {valor_experimental:.2e}')
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.title(title)
    plt.legend()
    plt.savefig(filename)
    plt.clf()

# Crear y guardar la gráfica de oscilación de neutrinos
crear_grafica_oscilacion(oscilacion_SPheno_1, oscilacion_CI_1, oscilacion_SPheno_2, oscilacion_CI_2, r'$|\Delta m_{\nu21}^2|_{SPheno}$', r'$|\Delta m_{\nu21}^2|_{CI}$', r'Oscilación de Neutrinos', valor_experimental, 'oscilacion_neutrinos.png')
"""


'''
# Crear el histograma para l1
l1_pos = [l for l in l1 if l > 0]
plt.hist(l1_pos, bins=100, edgecolor='black',histtype='step')
plt.title('Histograma de l1')
plt.xlabel('l1')
plt.ylabel('')
plt.savefig('histograma_l1.png')
plt.clf()

# Crear el histograma para l4Sig
l4Sig_pos = [l for l in l4Sig if l > 0]
plt.hist(l4Sig_pos, bins=100, edgecolor='black',histtype='step')
plt.title('Histograma de l4Sig')
plt.xlabel('l4Sig')
plt.ylabel('')
plt.savefig('histograma_l4Sig.png')
plt.clf()

# Crear el histograma para l4Eta
l4Eta_pos = [l for l in l4Eta if l > 0]
plt.hist(l4Eta_pos, bins=100, edgecolor='black',histtype='step')
plt.title('Histograma de l4Eta')
plt.xlabel('l4Eta')
plt.ylabel('')
plt.savefig('histograma_l4Eta.png')
plt.clf()

# Crear el histograma para l32HEta
l32HEta_pos = [l for l in l32HEta if l > 0]
plt.hist(l32HEta_pos, bins=100, edgecolor='black',histtype='step')
plt.title('Histograma de l32HEta')
plt.xlabel('l32HEta')
plt.ylabel('')
plt.savefig('histograma_l32HEta.png')
plt.clf()

# Crear el histograma para l33HEta
l33HEta_pos = [l for l in l33HEta if l > 0]
plt.hist(l33HEta_pos, bins=100, edgecolor='black',histtype='step')
plt.title('Histograma de l33HEta')
plt.xlabel('l33HEta')
plt.ylabel('')
plt.savefig('histograma_l33HEta.png')
plt.clf()

# Crear el histograma para cTri
cTri_pos = [c for c in cTri if c > 0]
plt.hist(cTri_pos, bins=100, edgecolor='black',histtype='step')
plt.title('Histograma de cTri')
plt.xlabel('cTri')
plt.ylabel('')
plt.savefig('histograma_cTri.png')
plt.clf()

MX01_pos = [i for i in MX01 if i > 0]
plt.hist(MX01_pos, bins=100, edgecolor='black',histtype='step')
plt.title('Histograma de MX01')
plt.xlabel('MX01')
plt.ylabel('')
plt.savefig('histograma_MX01.png')
plt.clf()

#mN22_pos = [i for i in nM22 if i > 0]
plt.hist(MX02, bins=100, edgecolor='black',histtype='step')
plt.title('Histograma de MX02')
plt.xlabel('MX02')
plt.ylabel('')
plt.savefig('histograma_MX02.png')
plt.clf()

#mN33_pos = [i for i in nM33 if i > 0]
plt.hist(MX03, bins=100, edgecolor='black',histtype='step')
plt.title('Histograma de MX03')
plt.xlabel('MX03')
plt.ylabel('')
plt.savefig('histograma_MX03.png')
plt.clf()


# Filtrar solo los valores positivos
m_nu2_SPheno_pos = [x for x, y in zip(m_nu2_SPheno, m_nu2_CI) if x > 0 and y > 0]
m_nu2_CI_pos = [y for x, y in zip(m_nu2_SPheno, m_nu2_CI) if x > 0 and y > 0]

# Crear el plot
plt.scatter(m_nu2_SPheno_pos, m_nu2_CI_pos, s=5)
plt.xlabel('m_nu2_SPheno')
plt.ylabel('m_nu2_CI')
plt.title('Plot de m_nu2_SPheno vs m_nu2_CI')
# Usar escala logarítmica en ambos ejes
plt.xscale('log')
plt.yscale('log')
plt.savefig('m2CI_m2SPheno.png')
plt.clf()




# Asegurarse de que las listas tengan la misma longitud
min_length = min(len(Omega_h2), len(MX01), len(MP01), len(MEtI))

# Filtrar valores positivos y ajustar las listas a la misma longitud
Omega_h2_pos = []
M_DM_red = []
M_DM_blue = []
M_DM_green = []

for i in range(min_length):
    if Omega_h2[i] > 0 and Omega_h2[i] < 1:
        M_DM_value = min(np.abs(MX01_1[i]), np.abs(MP01_1[i]), np.abs(MEtI[i]))
        if M_DM_value < 1e4 :
            Omega_h2_pos.append(Omega_h2[i])
            if np.abs(MX01_1[i]) == M_DM_value:
                M_DM_red.append(np.abs(MX01_1[i]))
                M_DM_blue.append(np.nan)
                M_DM_green.append(np.nan)
            elif np.abs(MP01_1[i]) == M_DM_value:
                M_DM_red.append(np.nan)
                M_DM_blue.append(np.abs(MP01_1[i]))
                M_DM_green.append(np.nan)
            elif np.abs(MEtI[i]) == M_DM_value:
                M_DM_red.append(np.nan)
                M_DM_blue.append(np.nan)
                M_DM_green.append(np.abs(MEtI[i]))

# Convertir listas a arrays de numpy para manejar NaNs
M_DM_red = np.array(M_DM_red)
M_DM_blue = np.array(M_DM_blue)
M_DM_green = np.array(M_DM_green)

# Hacer el plot
plt.scatter(M_DM_red, Omega_h2_pos, s=5, color='red', label='MX01')
plt.scatter(M_DM_blue, Omega_h2_pos, s=5, color='blue', label='MP01')
plt.scatter(M_DM_green, Omega_h2_pos, s=5, color='green', label='MEtI')
plt.axhline(y=0.1199, color='black', linestyle='--', label='Experimental value')
plt.ylim(0, 0.2)
plt.ylabel(r'$\Omega_{h^2}$')
plt.xlabel(r'$M_{DM}$ [GeV]')
plt.title(r'$\Omega_{h^2} vs M_{DM}$ from Random Walk')
plt.legend()
#plt.xscale('log')
#plt.yscale('log')
# Guardar la imagen
plt.savefig('Omega_h2-M_DM.png')
plt.clf()
'''

